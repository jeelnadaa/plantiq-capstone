"""
pipeline.py
===========
All RAG logic in one place:
  - Config  (reads .env)
  - PDF ingestion + chunking
  - FAISS vector store  (auto save / load)
  - Gemini LLM wrapper
  - Two RAG modes:
      1. disease_advisory(DiseaseInput)  →  CNN + env data → structured advisory
      2. answer_question(str)            →  plain user question → synthesised answer
"""

from __future__ import annotations

import os
import re
import pickle
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# ── third-party (installed via requirements.txt) ─────────────────────────────
import numpy as np
import faiss
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
import google.generativeai as genai

try:
    import fitz          # PyMuPDF  (preferred)
    _PDF_BACKEND = "pymupdf"
except ImportError:
    import pdfplumber    # fallback
    _PDF_BACKEND = "pdfplumber"

log = logging.getLogger(__name__)


# ╔══════════════════════════════════════════════════════╗
# ║  CONFIG                                              ║
# ╚══════════════════════════════════════════════════════╝

load_dotenv()

def _env(key: str, default: str = "") -> str:
    return os.getenv(key, default)

GEMINI_API_KEY = _env("GEMINI_API_KEY")
GEMINI_MODEL   = _env("GEMINI_MODEL",   "gemini-1.5-flash")
PDF_FOLDER     = _env("PDF_FOLDER",     "./knowledge_base")
INDEX_FOLDER   = _env("INDEX_FOLDER",   "./index")
TOP_K          = int(_env("TOP_K",      "5"))


def _validate_config():
    if not GEMINI_API_KEY or GEMINI_API_KEY == "your_gemini_api_key_here":
        raise ValueError("GEMINI_API_KEY is not set in your .env file.")


# ╔══════════════════════════════════════════════════════╗
# ║  DATA CLASSES                                        ║
# ╚══════════════════════════════════════════════════════╝

@dataclass
class Chunk:
    text: str
    source: str
    page: int


@dataclass
class DiseaseInput:
    """Everything the CNN + sensors provide for Mode 1."""
    disease: str
    confidence: float       # 0.0 – 1.0
    is_healthy: bool
    temperature_c: float
    humidity_pct: float
    rainfall_mm: float
    soil_ph: float
    soil_type: str
    elevation_m: float
    user_question: Optional[str] = None


@dataclass
class Result:
    answer: str
    sources: list[str] = field(default_factory=list)


# ╔══════════════════════════════════════════════════════╗
# ║  PDF INGESTION                                       ║
# ╚══════════════════════════════════════════════════════╝

def load_pdfs(folder: str) -> list[Chunk]:
    """
    Load every PDF in *folder* and return text chunks.
    Returns [] if the folder is missing or empty — caller handles the warning.
    """
    pdf_dir = Path(folder)
    if not pdf_dir.exists():
        return []

    pdf_files = list(pdf_dir.glob("**/*.pdf"))
    if not pdf_files:
        return []

    chunks: list[Chunk] = []
    for path in pdf_files:
        log.info("Reading %s …", path.name)
        for page_num, text in _extract_pages(str(path)):
            chunks.extend(_split(text, path.name, page_num))

    log.info("Loaded %d chunks from %d PDFs.", len(chunks), len(pdf_files))
    return chunks


def _extract_pages(path: str) -> list[tuple[int, str]]:
    if _PDF_BACKEND == "pymupdf":
        doc = fitz.open(path)
        pages = [(i + 1, _clean(p.get_text("text"))) for i, p in enumerate(doc)]
        doc.close()
    else:
        with pdfplumber.open(path) as pdf:
            pages = [(i + 1, _clean(p.extract_text() or "")) for i, p in enumerate(pdf.pages)]
    return [(n, t) for n, t in pages if t.strip()]


def _clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\x20-\x7E]", " ", text)
    return text.strip()


def _split(text: str, source: str, page: int,
           size: int = 400, overlap: int = 50) -> list[Chunk]:
    words = text.split()
    chunks, start = [], 0
    while start < len(words):
        end = min(start + size, len(words))
        chunks.append(Chunk(" ".join(words[start:end]), source, page))
        if end == len(words):
            break
        start += size - overlap
    return chunks


# ╔══════════════════════════════════════════════════════╗
# ║  VECTOR STORE  (FAISS)                               ║
# ╚══════════════════════════════════════════════════════╝

_EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
_DIM = 384
_IDX_FILE   = "faiss.index"
_CHUNK_FILE = "chunks.pkl"

class VectorStore:
    def __init__(self):
        log.info("Loading embedding model …")
        self._embedder = SentenceTransformer(_EMBED_MODEL)
        self._index = faiss.IndexFlatIP(_DIM)
        self._chunks: list[Chunk] = []

    # ── build ──────────────────────────────────────────

    def add(self, chunks: list[Chunk], batch: int = 64):
        texts = [c.text for c in chunks]
        all_embs = []
        for i in range(0, len(texts), batch):
            all_embs.append(
                self._embedder.encode(
                    texts[i:i+batch], convert_to_numpy=True,
                    normalize_embeddings=True, show_progress_bar=False,
                )
            )
        self._index.add(np.vstack(all_embs).astype("float32"))
        self._chunks.extend(chunks)
        log.info("Index now has %d vectors.", self._index.ntotal)

    # ── search ─────────────────────────────────────────

    def search(self, query: str, top_k: int = TOP_K) -> list[Chunk]:
        if self._index.ntotal == 0:
            return []
        q = self._embedder.encode(
            [query], convert_to_numpy=True, normalize_embeddings=True
        ).astype("float32")
        _, ids = self._index.search(q, top_k)
        return [self._chunks[i] for i in ids[0] if i != -1]

    # ── persist ────────────────────────────────────────

    def save(self, folder: str):
        Path(folder).mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._index, str(Path(folder) / _IDX_FILE))
        with open(Path(folder) / _CHUNK_FILE, "wb") as f:
            pickle.dump(self._chunks, f)
        log.info("Index saved → '%s'.", folder)

    def load(self, folder: str) -> bool:
        idx = Path(folder) / _IDX_FILE
        chk = Path(folder) / _CHUNK_FILE
        if not idx.exists() or not chk.exists():
            return False
        self._index = faiss.read_index(str(idx))
        with open(chk, "rb") as f:
            self._chunks = pickle.load(f)
        log.info("Index loaded ← '%s'  (%d vectors).", folder, self._index.ntotal)
        return True

    @property
    def is_empty(self) -> bool:
        return self._index.ntotal == 0


# ╔══════════════════════════════════════════════════════╗
# ║  LLM  (Gemini)                                       ║
# ╚══════════════════════════════════════════════════════╝

def _ask_gemini(prompt: str) -> str:
    genai.configure(api_key=GEMINI_API_KEY)
    try:
        model = genai.GenerativeModel(GEMINI_MODEL)
        return model.generate_content(prompt).text.strip()
    except Exception as e:
        log.error("Gemini error: %s", e)
        return f"[Error contacting Gemini: {e}]"


# ╔══════════════════════════════════════════════════════╗
# ║  RAG — MODE 1: CNN disease advisory                  ║
# ╚══════════════════════════════════════════════════════╝

def disease_advisory(inp: DiseaseInput, store: VectorStore) -> Result:
    """
    Healthy leaf  →  short healthy message, no retrieval.
    Diseased leaf →  retrieve relevant chunks, ask Gemini for a full advisory.
    """
    if inp.is_healthy:
        return Result(
            answer=(
                "The leaf appears healthy. No disease treatment is required.\n"
                "Continue regular monitoring and maintain good agronomic practices."
            )
        )

    # Build retrieval query
    query = (
        f"{inp.disease} coffee treatment prevention fertilizer "
        f"soil pH {inp.soil_ph} {inp.soil_type} "
        f"temperature {inp.temperature_c}C humidity {inp.humidity_pct}%"
    )
    if inp.user_question:
        query += f" {inp.user_question}"

    chunks = store.search(query)
    context = _fmt_context(chunks)

    user_q_line = f"\nFarmer's question: {inp.user_question}" if inp.user_question else ""

    prompt = f"""\
You are an expert agronomist specialising in coffee crop diseases.

CNN Diagnosis : {inp.disease}  ({inp.confidence*100:.1f}% confidence)
Temperature   : {inp.temperature_c} °C
Humidity      : {inp.humidity_pct} %
Rainfall      : {inp.rainfall_mm} mm
Soil pH       : {inp.soil_ph}  |  Soil type: {inp.soil_type}
Elevation     : {inp.elevation_m} m{user_q_line}

Knowledge base:
{context}

Give a practical advisory covering:
1. Disease explanation & symptoms
2. How the current environment is contributing
3. Immediate treatment steps
4. Fertilizer / soil recommendations
5. Prevention going forward

Be concise. Speak directly to the farmer."""

    return Result(answer=_ask_gemini(prompt), sources=_sources(chunks))


# ╔══════════════════════════════════════════════════════╗
# ║  RAG — MODE 2: Plain user question                   ║
# ╚══════════════════════════════════════════════════════╝

def answer_question(question: str, store: VectorStore) -> Result:
    """Retrieve top-5 chunks for the question and synthesise an answer."""
    chunks = store.search(question)

    if not chunks:
        # No index or no matches — Gemini answers from its own knowledge
        prompt = (
            f"You are a coffee crop expert. "
            f"Answer this farmer's question clearly and practically:\n\n{question}"
        )
        return Result(answer=_ask_gemini(prompt))

    prompt = (
        f"You are an expert in coffee crop cultivation and disease management.\n\n"
        f"Use the context below to answer the farmer's question.\n\n"
        f"Context:\n{_fmt_context(chunks)}\n\n"
        f"Question: {question}\n\nAnswer:"
    )
    return Result(answer=_ask_gemini(prompt), sources=_sources(chunks))


# ── shared helpers ────────────────────────────────────────────────────────────

def _fmt_context(chunks: list[Chunk]) -> str:
    return "\n\n".join(
        f"[{i+1}] {c.source} p.{c.page}\n{c.text}"
        for i, c in enumerate(chunks)
    ) or "No context retrieved."


def _sources(chunks: list[Chunk]) -> list[str]:
    seen, out = set(), []
    for c in chunks:
        key = f"{c.source}  (p.{c.page})"
        if key not in seen:
            seen.add(key)
            out.append(key)
    return out


# ╔══════════════════════════════════════════════════════╗
# ║  INDEX BOOTSTRAP  (called by main.py)                ║
# ╚══════════════════════════════════════════════════════╝

def get_store() -> VectorStore:
    """
    1. Try loading the saved index.
    2. If missing → ingest PDFs → save index.
    3. If PDF folder is also empty → warn and return an empty store
       (Gemini will still answer from its own knowledge).
    """
    _validate_config()
    store = VectorStore()

    if store.load(INDEX_FOLDER):
        return store

    log.info("No saved index — ingesting PDFs from '%s' …", PDF_FOLDER)
    chunks = load_pdfs(PDF_FOLDER)

    if not chunks:
        print(
            f"\n⚠️  PDF folder '{PDF_FOLDER}' is empty or missing.\n"
            "   Add PDFs and delete the index folder to rebuild.\n"
            "   Gemini will answer using its built-in knowledge for now.\n"
        )
        return store

    store.add(chunks)
    store.save(INDEX_FOLDER)
    return store
