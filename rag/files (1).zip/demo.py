"""
demo.py
=======
Simulates both RAG modes with hard-coded sample data.
Imported and run by main.py — not meant to be executed directly.

  Mode 1 (CNN):    Three disease scenarios the CNN might return.
  Mode 2 (Query):  Three plain farmer questions.
"""

from pipeline import DiseaseInput, VectorStore, disease_advisory, answer_question

# ── Mode 1 scenarios ──────────────────────────────────────────────────────────

CNN_SCENARIOS = [
    DiseaseInput(
        disease="Coffee Leaf Rust (Hemileia vastatrix)",
        confidence=0.94,
        is_healthy=False,
        temperature_c=22.5, humidity_pct=87.0, rainfall_mm=180.0,
        soil_ph=5.8, soil_type="loamy", elevation_m=1200.0,
        user_question="Which fungicide is safe to use near a stream?",
    ),
    DiseaseInput(
        disease="Coffee Leaf Miner (Leucoptera coffeella)",
        confidence=0.91,
        is_healthy=False,
        temperature_c=28.0, humidity_pct=60.0, rainfall_mm=55.0,
        soil_ph=6.0, soil_type="sandy loam", elevation_m=750.0,
        user_question=None,   # farmer did not type a question
    ),
    DiseaseInput(
        disease="Cercospora Blight (Cercospora coffeicola)",
        confidence=0.86,
        is_healthy=False,
        temperature_c=24.0, humidity_pct=82.0, rainfall_mm=130.0,
        soil_ph=4.9, soil_type="clay loam", elevation_m=1050.0,
        user_question="My soil test shows low nitrogen — what fertilizer should I use?",
    ),
    DiseaseInput(
        disease="",           # CNN found no disease
        confidence=0.99,
        is_healthy=True,      # → skips retrieval, returns healthy message
        temperature_c=21.0, humidity_pct=75.0, rainfall_mm=100.0,
        soil_ph=6.2, soil_type="loamy", elevation_m=1100.0,
    ),
]

# ── Mode 2 scenarios ──────────────────────────────────────────────────────────

QUESTIONS = [
    "How do I treat coffee leaf rust organically?",
    "What is the best fertilizer for coffee plants at pH 5.5?",
    "How can I prevent coffee berry disease from spreading?",
]


# ── Runner (called from main.py) ──────────────────────────────────────────────

def run_cnn_mode(store: VectorStore, scenario_index: int = 0):
    """Run one CNN scenario through the disease advisory pipeline."""
    inp = CNN_SCENARIOS[scenario_index]
    _print_header(f"MODE 1 — CNN Disease Advisory  (scenario {scenario_index})")
    print(f"  Disease    : {inp.disease or 'None (healthy)'}")
    print(f"  Confidence : {inp.confidence*100:.0f}%")
    print(f"  Temp / Hum : {inp.temperature_c}°C  /  {inp.humidity_pct}%")
    print(f"  Soil       : pH {inp.soil_ph}  •  {inp.soil_type}  •  {inp.elevation_m}m")
    print(f"  Question   : {inp.user_question or '(none)'}")
    result = disease_advisory(inp, store)
    _print_result(result)


def run_query_mode(store: VectorStore, question_index: int = 0):
    """Run one plain question through the Q&A pipeline."""
    question = QUESTIONS[question_index]
    _print_header(f"MODE 2 — Farmer Question  (scenario {question_index})")
    print(f"  Q: {question}")
    result = answer_question(question, store)
    _print_result(result)


# ── Private helpers ───────────────────────────────────────────────────────────

def _print_header(title: str):
    print("\n" + "=" * 65)
    print(f"  {title}")
    print("=" * 65)


def _print_result(result):
    print()
    print(result.answer)
    if result.sources:
        print("\n--- Sources ---")
        for s in result.sources:
            print(f"  • {s}")
    print()
